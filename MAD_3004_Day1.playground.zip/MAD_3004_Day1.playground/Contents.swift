//: Playground - noun: a place where people can play

import UIKit

//to declare the variable
var str = "Hello, playground"

// to print the value/string
print(str)

// \(str) used to print variable value and terminator to terminate the end statement like (\n, ..,)
print("This is our String: \(str)",terminator:" ")

//use separator for separating multiple prompts
print("1", "2", "3", "4", "5", separator: "..")

//to print multiple records
var n1 = 10
print("Number 1: ",n1,"string: ", str)

var n2 = 20
print("Number 2: ",n2)

var sum = n1 + n2
print("Sum is :", sum)
print("Sum is :", n1+n2)

//n1 = "test"
//print("n1 : ", n1)

//to explicitly assign a variable
var a:Int = 10
print("a = ",a)

var greet:String = "Good Morning"
print("Greetings:", greet)


var b:Float = 5.5
print("b = ", b)

var c:String = "Hello Swift"
print("c = ", c)

var emoji = "😇"
print("Its a \(emoji) hour")

var pi = 3.14
pi = 3.190
print("Pi = ",pi)

//optional values
let myNum:Int?  //optional
myNum = nil

if myNum != nil {
    print("myNum: ",myNum!)
}
else{
    print("myNum is nil")
}

//optional values
let possibleNumber = "hello" //"123"
let convertedNumber:Int?

convertedNumber = Int(possibleNumber)

if convertedNumber != nil{
    print("Converted Number", convertedNumber!)
}
else{
    print("converted Number is Nil")
}

//Looping
for i in 1...5{
    print("i = ",i)
}

for i in 1..<5{
    print("i = ",i)
}

let languages:[String]
languages = ["English", "Spanish", "French", "German"]

for i in languages{
    print("i", i)
}
var number: Int = 1

for _ in 1...5{
    number *= 5;
    
}
print("sum = ",number)

// sum of numbers
/*
var summ: Int = 1

for _ in 1..<5{
    summ = summ + 1;
}
print("summ = ",summ)
*/

//Using Stride
var Interval:Int = 5
for i in stride(from: 0, to: 50, by: Interval){
    print(i, " ", terminator: " ")
}

//
var j = 1
while (j < 5) {
    print("Value of J is \(j)")
    j = j + 1
}

j = 5
repeat{
    print("Repeat : ", j)
    j = j + 2
}while (j<10)

// Switch
var num1 = 100
switch num1 {
case 100 :
    print("value of num1 is 100")
    fallthrough
    
case 10,15 :
    print("value of num1 is either 10 or 15")
case 5:
    print("Value of num1 is 5")
default :
    print(" Default case")
    
}

let approximateCount = 62
let countedThings = "moons orbiting Saturn"
let naturalCount: String
switch approximateCount {
case 0:
    naturalCount = "no"
case 1..<5:
    naturalCount = "a few"
case 5..<12:
    naturalCount = "Several"
case 12..<100:
    naturalCount = "dozens of"
case 100..<1000:
    naturalCount = "hundreds of"
default:
    naturalCount = "many"
}
print("There are \(naturalCount) \(countedThings).")

